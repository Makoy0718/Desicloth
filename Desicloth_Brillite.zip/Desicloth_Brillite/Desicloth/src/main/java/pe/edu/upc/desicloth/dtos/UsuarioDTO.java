package pe.edu.upc.desicloth.dtos;

public class UsuarioDTO {

    private int idUsuario;
    private String nombreUsuario;
    private String correoUsuario;
    private String contrasenaUsuario;
    private RolDTO rolId;


    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getCorreoUsuario() {
        return correoUsuario;
    }

    public void setCorreoUsuario(String correoUsuario) {
        this.correoUsuario = correoUsuario;
    }

    public String getContrasenaUsuario() {
        return contrasenaUsuario;
    }

    public void setContrasenaUsuario(String contrasenaUsuario) {
        this.contrasenaUsuario = contrasenaUsuario;
    }

    public RolDTO getRolId() {
        return rolId;
    }

    public void setRolId(RolDTO rolId) {
        this.rolId = rolId;
    }
}
