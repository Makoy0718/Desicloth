package pe.edu.upc.desicloth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesiclothApplication {

	public static void main(String[] args) {
		SpringApplication.run(DesiclothApplication.class, args);
	}

}
