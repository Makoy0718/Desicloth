package pe.edu.upc.desicloth.servicesimplements;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.desicloth.entities.Genero;
import pe.edu.upc.desicloth.repositories.IGeneroRepository;
import pe.edu.upc.desicloth.servicesinterfaces.IGeneroService;

import java.util.List;

@Service
public class GeneroServiceImplement implements IGeneroService {

    @Autowired
    public IGeneroRepository gR;


    @Override
    public List<Genero> list() {
        return gR.findAll();
    }

    @Override
    public void insert(Genero g) {
        gR.save(g);
    }

    @Override
    public void update(Genero g) {
        gR.save(g);
    }

    @Override
    public void delete(int id) {
        gR.deleteById((long) id);
    }
}
