package pe.edu.upc.desicloth.dtos;

public class RolDTO {
}
